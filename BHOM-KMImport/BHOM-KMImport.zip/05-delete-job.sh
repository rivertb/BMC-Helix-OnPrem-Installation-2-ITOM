#!/bin/bash
kubectl delete job single-solution-import-job -n helix
