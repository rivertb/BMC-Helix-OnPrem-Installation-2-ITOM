#!/bin/bash
kubectl get job -n helix | grep single
