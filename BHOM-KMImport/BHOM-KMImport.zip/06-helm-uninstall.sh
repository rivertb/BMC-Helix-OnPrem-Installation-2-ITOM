#!/bin/bash
helm uninstall single-solution-import -n helix
