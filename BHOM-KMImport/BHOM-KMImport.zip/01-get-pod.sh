#!/bin/bash
kubectl get pods -n helix | grep deployment
