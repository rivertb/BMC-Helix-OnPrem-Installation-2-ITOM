#!/bin/bash
kubectl get pod -n helix | grep single
